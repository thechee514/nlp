def word_lengths(word_list):
    num_list = []
    for word in word_list:
        num_list.append(len(word))
    return num_list
